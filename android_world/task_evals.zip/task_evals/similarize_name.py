def _similarize_name(name: str) -> str:
    """
    制造一个看起来几乎一样但不同的名字，用于迷惑 agent。
    """
    import random

    similar_map = {
        "a": "ɑ", "e": "е", "i": "í", "o": "ο", "u": "υ",
        "l": "1", "s": "ʂ", "n": "ᴎ", "m": "ᴍ", "g": "ɡ",
    }

    chars = list(name)
    indices = [i for i, c in enumerate(chars) if c.lower() in similar_map]

    if not indices:
        return name + " Jr."

    idx = random.choice(indices)
    original = chars[idx].lower()
    chars[idx] = similar_map[original]

    return "".join(chars)


def generate_similar_contacts(
    base_name: str,
    num_contacts: int,
    max_attempts_per_contact: int = 5,
) -> list[str]:
    """
    生成多个彼此不同、且与 base_name 高度相似的联系人名
    """
    similar_names = set()
    attempts = 0
    max_attempts = num_contacts * max_attempts_per_contact

    while len(similar_names) < num_contacts and attempts < max_attempts:
        new_name = _similarize_name(base_name)

        # 保证不等于原名 & 不重复
        if new_name != base_name and new_name not in similar_names:
            similar_names.add(new_name)

        attempts += 1

    if len(similar_names) < num_contacts:
        raise RuntimeError(
            f"Only generated {len(similar_names)} similar names for '{base_name}'"
        )

    return list(similar_names)
